// Student Management System - frontend (Fetch API, no page reloads)
const PORT = "5000";
let BASE = "";
let API = "/api/students";
const FIELDS = ["name", "roll_no", "class_name", "marks", "contact"];

const $ = (id) => document.getElementById(id);
const form = $("student-form");
const formPanel = document.querySelector(".form-panel");
const tbody = $("table-body");
const searchInput = $("search");
const submitBtn = $("submit-btn");
const cancelBtn = $("cancel-btn");

let editingId = null;
let students = [];
let lastSavedId = null;

// ---------- small helpers ----------
const esc = (v) => { const d = document.createElement("div"); d.textContent = v; return d.innerHTML; };

function initials(name) {
  const p = name.trim().split(/\s+/);
  return ((p[0] || "")[0] + (p.length > 1 ? p[p.length - 1][0] : "")).toUpperCase();
}
function avatarBg(name) {
  let h = 0;
  for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const hue = h % 360;
  return `linear-gradient(135deg, hsl(${hue} 70% 52%), hsl(${(hue + 40) % 360} 75% 42%))`;
}
function grade(m) {
  if (m >= 90) return ["A+", "c-a"];
  if (m >= 80) return ["A", "c-a"];
  if (m >= 70) return ["B", "c-b"];
  if (m >= 60) return ["C", "c-c"];
  if (m >= 40) return ["D", "c-c"];
  return ["F", "c-f"];
}

let toastTimer;
function toast(msg, bad = false) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.toggle("bad", bad);
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 2800);
}

function setMode(mode) {
  const server = mode === "server";
  $("status").dataset.state = server ? "ok" : "wait";
  $("status-text").textContent = server ? "Connected to Flask + SQLite" : "Browser mode (no server)";
  $("offline").hidden = server;
  if (!server) {
    $("offline-title").textContent = "Running in browser mode.";
    $("offline-detail").textContent =
      "Everything works and your records are saved in this browser. To store them in SQLite, start the Flask server and press Connect.";
  }
}
const setOnline = (ok) => setMode(ok ? "server" : "local");

// Find the Flask API: same address as this page first, then http://127.0.0.1:5000.
async function detectServer() {
  const candidates = window.location.protocol === "file:" ? [] : [""];
  for (const port of [PORT, "5001", "5002"]) candidates.push(`http://127.0.0.1:${port}`);
  for (const base of candidates) {
    try {
      const res = await fetch(`${base}/api/stats`);
      const data = await res.json();
      if (res.ok && "total" in data) {
        BASE = base;
        API = `${BASE}/api/students`;
        return true;
      }
    } catch (_) { /* try next */ }
  }
  return false;
}

// ---------- Browser mode (used when no Flask server is running) ----------
let LOCAL = false;
const STORE_KEY = "sms-students-v1";

// Falls back to memory if the browser blocks localStorage (data then lasts until the tab closes).
let memStore = { next: 1, rows: [] };
function loadStore() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    return raw ? JSON.parse(raw) : { next: 1, rows: [] };
  } catch (_) { return memStore; }
}
function saveStore(db) {
  memStore = db;
  try { localStorage.setItem(STORE_KEY, JSON.stringify(db)); } catch (_) {}
}
function fail(message, fields) { const e = new Error(message); e.fields = fields || {}; return e; }

function localRequest(url, options = {}) {
  const u = new URL(url, "http://local");
  const method = (options.method || "GET").toUpperCase();
  const m = u.pathname.match(/^\/api\/students\/(\d+)$/);
  const id = m ? Number(m[1]) : null;
  const db = loadStore();
  const body = options.body ? JSON.parse(options.body) : null;
  const clean = (b) => ({
    name: String(b.name).trim(), roll_no: String(b.roll_no).trim(), class_name: String(b.class_name).trim(),
    marks: Math.round(Number(b.marks) * 100) / 100, contact: String(b.contact).trim(),
  });
  const check = (b, ignoreId) => {
    const errs = validate({ ...Object.fromEntries(FIELDS.map((f) => [f, String(b[f] ?? "").trim()])) });
    if (Object.keys(errs).length) throw fail("Please fix the highlighted fields.", errs);
    if (db.rows.some((r) => r.id !== ignoreId && r.roll_no.toLowerCase() === String(b.roll_no).trim().toLowerCase()))
      throw fail("Roll number already exists.", { roll_no: "This roll number is already taken." });
  };

  if (u.pathname === "/api/stats") {
    const n = db.rows.length;
    const total = db.rows.reduce((a, r) => a + r.marks, 0);
    return Promise.resolve({ total: n, average: n ? Math.round((total / n) * 100) / 100 : 0, top: n ? Math.max(...db.rows.map((r) => r.marks)) : 0 });
  }
  if (u.pathname === "/api/students" && method === "GET") {
    const q = (u.searchParams.get("q") || "").trim().toLowerCase();
    const rows = [...db.rows].reverse().filter((r) => !q ||
      [r.name, r.roll_no, r.class_name].some((x) => x.toLowerCase().includes(q)));
    return Promise.resolve(rows);
  }
  try {
    if (u.pathname === "/api/students" && method === "POST") {
      check(body, null);
      const row = { id: db.next++, ...clean(body) };
      db.rows.push(row); saveStore(db);
      return Promise.resolve(row);
    }
    if (id !== null && method === "PUT") {
      const i = db.rows.findIndex((r) => r.id === id);
      if (i < 0) throw fail("Student not found.");
      check(body, id);
      db.rows[i] = { id, ...clean(body) }; saveStore(db);
      return Promise.resolve(db.rows[i]);
    }
    if (id !== null && method === "DELETE") {
      const i = db.rows.findIndex((r) => r.id === id);
      if (i < 0) throw fail("Student not found.");
      db.rows.splice(i, 1); saveStore(db);
      return Promise.resolve({ message: "Student deleted." });
    }
  } catch (e) { return Promise.reject(e); }
  return Promise.reject(fail("Unknown request."));
}

async function request(url, options = {}) {
  if (LOCAL) return localRequest(url, options);
  let res;
  try {
    res = await fetch(url, { headers: { "Content-Type": "application/json" }, ...options });
  } catch (_) {
    const e = new Error("Cannot reach the server. Start it with: python app.py");
    e.network = true;
    throw e;
  }
  const data = await res.json().catch(() => null);
  if (data === null) {
    throw new Error(`Unexpected reply from server (${res.status}). Open the app at http://127.0.0.1:${PORT}`);
  }
  if (!res.ok) {
    const e = new Error(data.error || "Something went wrong.");
    e.fields = data.fields || {};
    throw e;
  }
  return data;
}

const debounce = (fn, ms = 250) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

// ---------- validation ----------
function validate(v) {
  const e = {};
  if (v.name.length < 2) e.name = "Enter the full name (at least 2 characters).";
  else if (!/^[A-Za-z][A-Za-z .'-]*$/.test(v.name)) e.name = "Use letters, spaces and . ' - only.";
  if (!v.roll_no) e.roll_no = "Enter a roll number.";
  else if (!/^[A-Za-z0-9/_-]{1,20}$/.test(v.roll_no)) e.roll_no = "Use letters, digits, / _ - (max 20).";
  if (!v.class_name) e.class_name = "Enter the class, e.g. B.Tech CSE.";
  const m = Number(v.marks);
  if (v.marks === "" || Number.isNaN(m) || m < 0 || m > 100) e.marks = "Enter a number from 0 to 100.";
  if (!/^[6-9]\d{9}$/.test(v.contact)) e.contact = "10 digits, starting with 6, 7, 8 or 9.";
  return e;
}
function showErrors(errors) {
  FIELDS.forEach((f) => {
    $(f).classList.toggle("invalid", Boolean(errors[f]));
    form.querySelector(`.err[data-for="${f}"]`).textContent = errors[f] || "";
  });
  const first = FIELDS.find((f) => errors[f]);
  if (first) $(first).focus();
}

// ---------- render ----------
function render() {
  tbody.innerHTML = students.map((s) => {
    const [g, cls] = grade(s.marks);
    return `
    <tr class="${s.id === lastSavedId ? "flash" : ""}">
      <td><div class="who"><span class="avatar" style="background:${avatarBg(s.name)}">${esc(initials(s.name))}</span>${esc(s.name)}</div></td>
      <td><span class="roll">${esc(s.roll_no)}</span></td>
      <td>${esc(s.class_name)}</td>
      <td><span class="marks">${Number(s.marks).toFixed(2)} <span class="chip ${cls}">${g}</span></span></td>
      <td>${esc(s.contact)}</td>
      <td>
        <button class="btn sm edit" data-action="edit" data-id="${s.id}">Edit</button>
        <button class="btn sm del" data-action="delete" data-id="${s.id}">Delete</button>
      </td>
    </tr>`;
  }).join("");
  lastSavedId = null;

  const q = searchInput.value.trim();
  $("count-label").textContent = `${students.length} record${students.length === 1 ? "" : "s"} shown`;
  const empty = students.length === 0;
  $("empty").hidden = !empty;
  $("sample-btn").hidden = !(empty && !q);
  if (empty) {
    $("empty-text").textContent = q
      ? `No student matches "${q}". Check the spelling or try a roll number.`
      : "No students yet. Add one above, or load a few samples.";
  }
}

async function loadStudents() {
  const q = searchInput.value.trim();
  try {
    students = await request(q ? `${API}?q=${encodeURIComponent(q)}` : API);
    render();
  } catch (err) { toast(err.message, true); }
}
async function loadStats() {
  try {
    const s = await request(`${BASE}/api/stats`);
    $("stat-total").textContent = s.total;
    $("stat-avg").textContent = Number(s.average).toFixed(1);
    $("stat-top").textContent = Number(s.top).toFixed(1);
  } catch (_) { /* banner already shown */ }
}
async function refresh() {
  LOCAL = false;
  if (await detectServer()) {
    setMode("server");
  } else {
    LOCAL = true; BASE = ""; API = "/api/students";
    setMode("local");
  }
  await Promise.all([loadStudents(), loadStats()]);
}
// after the first detection, normal reloads skip re-detecting
const reload = () => Promise.all([loadStudents(), loadStats()]);

// ---------- form modes ----------
function resetForm() {
  editingId = null;
  form.reset();
  showErrors({});
  formPanel.classList.remove("editing");
  $("form-title").textContent = "Add a student";
  $("form-sub").textContent = "Fill in every field, then save the record.";
  submitBtn.textContent = "Save student";
  cancelBtn.hidden = true;
}
function startEdit(id) {
  const s = students.find((x) => x.id === id);
  if (!s) return;
  editingId = id;
  FIELDS.forEach((f) => ($(f).value = s[f]));
  showErrors({});
  formPanel.classList.add("editing");
  $("form-title").textContent = "Update student";
  $("form-sub").textContent = `Editing ${s.name}. Change the details and save.`;
  submitBtn.textContent = "Save changes";
  cancelBtn.hidden = false;
  formPanel.scrollIntoView({ behavior: "smooth", block: "center" });
  $("name").focus();
}

// ---------- events ----------
form.addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const values = {};
  FIELDS.forEach((f) => (values[f] = $(f).value.trim()));
  const errors = validate(values);
  showErrors(errors);
  if (Object.keys(errors).length) return;

  submitBtn.disabled = true;
  try {
    const wasEditing = editingId !== null;
    const saved = await request(wasEditing ? `${API}/${editingId}` : API, {
      method: wasEditing ? "PUT" : "POST",
      body: JSON.stringify({ ...values, marks: Number(values.marks) }),
    });
    lastSavedId = saved.id;
    toast(wasEditing ? "Student updated." : "Student added.");
    resetForm();
    await reload();
  } catch (err) {
    if (err.fields && Object.keys(err.fields).length) showErrors(err.fields);
    toast(err.message, true);
  } finally { submitBtn.disabled = false; }
});
cancelBtn.addEventListener("click", resetForm);
$("contact").addEventListener("input", (e) => { e.target.value = e.target.value.replace(/\D/g, "").slice(0, 10); });
searchInput.addEventListener("input", debounce(loadStudents));
$("retry-btn").addEventListener("click", refresh);

tbody.addEventListener("click", (ev) => {
  const btn = ev.target.closest("button[data-action]");
  if (!btn) return;
  const id = Number(btn.dataset.id);
  if (btn.dataset.action === "edit") startEdit(id);
  if (btn.dataset.action === "delete") askDelete(id);
});

const dlg = $("confirm");
function askDelete(id) {
  const s = students.find((x) => x.id === id);
  if (!s) return;
  $("confirm-text").textContent = `Delete ${s.name} (${s.roll_no})? This cannot be undone.`;
  dlg.dataset.id = id;
  dlg.showModal();
}
$("confirm-no").addEventListener("click", () => dlg.close());
$("confirm-yes").addEventListener("click", async () => {
  const id = Number(dlg.dataset.id);
  dlg.close();
  try {
    await request(`${API}/${id}`, { method: "DELETE" });
    toast("Student deleted.");
    if (editingId === id) resetForm();
    await reload();
  } catch (err) { toast(err.message, true); }
});

// sample data (handy for demos / screen recording)
$("sample-btn").addEventListener("click", async () => {
  const sample = [
    ["Riya Sharma", "B1/02", "B.Tech CSE", 91, "9123456780"],
    ["Kabir Joshi", "B1/03", "B.Tech CSE", 76, "9988776655"],
    ["Uday Gawande", "B1/01", "B.Tech IT", 82, "9876501234"],
    ["Ananya Deshmukh", "B2/07", "B.Tech ECE", 68, "8899001122"],
    ["Aarav Patil", "B2/09", "B.Tech CSE", 95, "7001234567"],
  ];
  for (const [name, roll_no, class_name, marks, contact] of sample) {
    try { await request(API, { method: "POST", body: JSON.stringify({ name, roll_no, class_name, marks, contact }) }); }
    catch (err) { if (err.network) return toast(err.message, true); }
  }
  toast("Sample students added.");
  reload();
});

// theme switcher (remembered between visits)
function setTheme(t) {
  document.documentElement.dataset.theme = t;
  document.querySelectorAll(".swatch").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.theme === t)));
  try { localStorage.setItem("sms-theme", t); } catch (_) {}
}
document.querySelectorAll(".swatch").forEach((b) => b.addEventListener("click", () => setTheme(b.dataset.theme)));
let saved = "lagoon";
try { saved = localStorage.getItem("sms-theme") || "lagoon"; } catch (_) {}
setTheme(saved);

// ---------- init ----------
refresh();
