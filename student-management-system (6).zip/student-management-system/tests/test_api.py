import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as appmod

GOOD = {"name": "Riya Sharma", "roll_no": "B1/02", "class_name": "B.Tech CSE", "marks": 91, "contact": "9123456780"}


def make_client():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    appmod.app.config["DATABASE"] = path
    appmod.init_db()
    appmod.app.config["TESTING"] = True
    return appmod.app.test_client(), path


def test_full_crud_flow():
    c, path = make_client()
    try:
        r = c.post("/api/students", json=GOOD)
        assert r.status_code == 201
        sid = r.get_json()["id"]

        assert c.post("/api/students", json={**GOOD, "roll_no": "b1/02"}).status_code == 409  # duplicate, case-insensitive
        assert c.post("/api/students", json={**GOOD, "roll_no": "B1/09", "contact": "123"}).status_code == 400
        assert c.post("/api/students", json={**GOOD, "roll_no": "B1/09", "marks": 150}).status_code == 400

        assert len(c.get("/api/students").get_json()) == 1
        assert len(c.get("/api/students?q=riya").get_json()) == 1
        assert c.get("/api/students?q=nobody").get_json() == []  # non-existent student

        r = c.put(f"/api/students/{sid}", json={**GOOD, "marks": 88})
        assert r.status_code == 200 and r.get_json()["marks"] == 88
        assert c.put("/api/students/999", json=GOOD).status_code == 404

        assert c.get("/api/stats").get_json()["total"] == 1
        assert c.delete(f"/api/students/{sid}").status_code == 200
        assert c.delete(f"/api/students/{sid}").status_code == 404
    finally:
        os.remove(path)
